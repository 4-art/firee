const mockData = [
  {
    img: "/images/uni.png",
    name: "Unemo",
  },
  {
    img: "/images/chameleon.png",
    name: "Greeny",
  },
  {
    img: "/images/chick.png",
    name: "Chicky",
  },
  {
    img: "/images/kitty.png",
    name: "Super cat",
  },
  {
    img: "/images/panda.png",
    name: "Sleepy",
  },
  {
    img: "/images/police.png",
    name: "Angry police",
  },
  {
    img: "/images/unicorn.png",
    name: "Queen",
  },
];

export default mockData;
